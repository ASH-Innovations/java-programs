package com.kingsleynorth.automation.base;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import org.apache.commons.io.FileUtils;

/**
 * 🚀 BasePage - Contains common reusable methods for page interactions. -
 * Handles WebDriver actions (click, type, getText, scroll, etc.) - Implements
 * explicit, implicit, and fluent waits - Provides JavaScript Executor for
 * complex interactions - Implements a dynamic XPath generator for flexible
 * element location - Takes screenshots for debugging failures
 */
public class BasePage {

	protected WebDriver driver;
	protected WebDriverWait wait;
	protected Actions actions;
	protected JavascriptExecutor jsExecutor;

	/**
	 * ✅ Constructor - Initializes WebDriver, Waits, Actions & JavaScriptExecutor.
	 */
	public BasePage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Explicit wait
		this.actions = new Actions(driver);
		this.jsExecutor = (JavascriptExecutor) driver;
	}

	/**
	 * ✅ Clicks on an element after waiting for its visibility.
	 */
	public void clickElement(By locator) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to click element: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Types text into an input field after clearing existing text.
	 */
	public void typeText(By locator, String text) {
		try {
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			element.clear();
			element.sendKeys(text);
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to type text in element: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Retrieves text from an element.
	 */
	public String getElementText(By locator) {
		try {
			return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).getText();
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to get text from element: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Waits until an element is visible.
	 */
	public void waitForElementVisibility(By locator, int timeout) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(timeout))
					.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {
			throw new RuntimeException("❌ Element not visible: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Fluent wait for elements with polling mechanism.
	 */
	public WebElement fluentWait(By locator, int timeout, int pollingTime) {
		try {
			Wait<WebDriver> fluentWait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(timeout))
					.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class);
			return fluentWait.until(driver -> driver.findElement(locator));
		} catch (Exception e) {
			throw new RuntimeException("❌ Element not found using fluent wait: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Scrolls to a specific element using JavaScript.
	 */
	public void scrollToElement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to scroll to element: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Scrolls to the bottom of the page.
	 */
	public void scrollToBottom() {
		try {
			jsExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to scroll to bottom | " + e.getMessage());
		}
	}

	/**
	 * ✅ Takes a screenshot and saves it in the screenshots folder.
	 */
	public void takeScreenshot(String filename) {
		try {
			File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcFile, new File("screenshots/" + filename + ".png"));
		} catch (IOException e) {
			throw new RuntimeException("❌ Error capturing screenshot: " + e.getMessage());
		}
	}

	/**
	 * ✅ Moves to a specified element using Actions class.
	 */
	public void moveToElement(By locator) {
		try {
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			actions.moveToElement(element).perform();
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to move to element: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Selects a dropdown option by visible text.
	 */
	public void selectDropdownByText(By locator, String text) {
		try {
			Select dropdown = new Select(wait.until(ExpectedConditions.visibilityOfElementLocated(locator)));
			dropdown.selectByVisibleText(text);
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to select dropdown option: " + text + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Generates a dynamic XPath for flexible element location.
	 */
	public String generateXPath(String tagName, String attribute, String value, boolean contains, int index) {
		try {
			String xpath = contains ? "//" + tagName + "[contains(@" + attribute + ",'" + value + "')]"
					: "//" + tagName + "[@" + attribute + "='" + value + "']";

			if (index > 0) {
				xpath += "[" + index + "]";
			}
			return xpath;
		} catch (Exception e) {
			throw new RuntimeException("❌ Error generating XPath | " + e.getMessage());
		}
	}

	/**
	 * ✅ Retrieves all elements matching a locator.
	 */
	public List<WebElement> getElements(By locator) {
		try {
			return driver.findElements(locator);
		} catch (Exception e) {
			throw new RuntimeException("❌ Unable to retrieve elements: " + locator + " | " + e.getMessage());
		}
	}

	/**
	 * ✅ Checks if an element is present.
	 */
	public boolean isElementPresent(By locator) {
		try {
			driver.findElement(locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * ✅ Checks if an element is displayed.
	 */
	public boolean isElementDisplayed(By locator) {
		try {
			return driver.findElement(locator).isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
