package com.kingsleynorth.automation.pages;

import com.kingsleynorth.automation.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * 🚀 LoginPage - Represents the login page in POM structure.
 * - Stores locators for login elements
 * - Provides actions to perform login
 * - Extends BasePage to reuse methods
 */
public class LoginPage extends BasePage {
    
    // ✅ Locators (By objects) for login fields
    private By usernameField = By.xpath("//input[@id='email']");   // Replace with actual ID
    private By passwordField = By.xpath("//input[@id='pass']");   // Replace with actual ID
    private By loginButton = By.xpath("//span[contains(text(),'Sign In')]"); // Replace with actual XPath
    private By errorMessage = By.id("error-msg");   // Replace with actual ID

    /**
     * ✅ Constructor - Initializes WebDriver
     */
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * ✅ Enters the username into the username field.
     */
    public void enterUsername(String username) {
        typeText(usernameField, username);
    }

    /**
     * ✅ Enters the password into the password field.
     */
    public void enterPassword(String password) {
        typeText(passwordField, password);
    }

    /**
     * ✅ Clicks the login button.
     */
    public void clickLoginButton() {
        clickElement(loginButton);
    }

    /**
     * ✅ Performs login using provided credentials.
     */
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }

    /**
     * ✅ Retrieves error message text (for invalid login cases).
     */
    public String getErrorMessage() {
        return getElementText(errorMessage);
    }
}
