package com.kingsleynorth.automation.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;

/**
 * 🚀 BaseTest - Manages WebDriver setup and teardown for all test cases. -
 * Reads configurations from config.properties - Initializes WebDriver
 * dynamically based on browser selection - Uses ThreadLocal for parallel
 * execution - Implements WebDriver waits (Implicit & Explicit) - Takes
 * screenshots on test failures - Supports headless execution mode for CI/CD -
 * Ensures WebDriver is properly closed after tests
 */
public class BaseTest {
	protected static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
	protected static WebDriverWait wait;
	protected static Properties config;

	/**
	 * ✅ Constructor: Loads the configuration file (config.properties)
	 */
	public BaseTest() {
		loadConfig();
	}

	/**
	 * ✅ Reads configuration settings from 'config/config.properties'
	 */
	private void loadConfig() {
	    try {
	        config = new Properties();
	        InputStream input = getClass().getClassLoader().getResourceAsStream("config/config.properties");

	        if (input == null) {
	            throw new RuntimeException("⚠️ config.properties file not found in resources/config/ folder.");
	        }

	        config.load(input);
	        input.close();  // Close stream after use
	    } catch (IOException e) {
	        throw new RuntimeException("⚠️ Error loading config.properties: " + e.getMessage());
	    }
	}

	/**
	 * ✅ Initializes WebDriver before each test (TestNG @BeforeMethod) - Reads
	 * browser type from config.properties - Supports headless execution for CI/CD -
	 * Uses WebDriverManager to set up drivers dynamically - Sets up implicit and
	 * explicit waits - Maximizes browser window - Opens base URL from
	 * config.properties
	 */
	@BeforeMethod
	public void initializeDriver() {
		String browser = config.getProperty("browser").toLowerCase().trim();
		boolean headlessMode = Boolean.parseBoolean(config.getProperty("headlessMode"));

		switch (browser) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			ChromeOptions chromeOptions = new ChromeOptions();
			if (headlessMode)
				chromeOptions.addArguments("--headless");
			driver.set(new ChromeDriver(chromeOptions));
			break;

		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions firefoxOptions = new FirefoxOptions();
			if (headlessMode)
				firefoxOptions.addArguments("--headless");
			driver.set(new FirefoxDriver(firefoxOptions));
			break;

		case "edge":
			WebDriverManager.edgedriver().setup();
			EdgeOptions edgeOptions = new EdgeOptions();
			if (headlessMode)
				edgeOptions.addArguments("--headless");
			driver.set(new EdgeDriver(edgeOptions));
			break;

		case "safari":
			if (headlessMode) {
				throw new RuntimeException("❌ Safari does not support headless mode.");
			}
			driver.set(new SafariDriver());
			break;

		default:
			throw new RuntimeException("❌ Invalid browser specified in config.properties");
		}

		// ✅ Setting implicit wait for all elements globally
		driver.get().manage().timeouts()
				.implicitlyWait(Duration.ofSeconds(Integer.parseInt(config.getProperty("implicitWait"))));

		// ✅ Maximizing browser window for better visibility
		driver.get().manage().window().maximize();

		// ✅ Initializing explicit wait (used in BasePage)
		wait = new WebDriverWait(driver.get(),
				Duration.ofSeconds(Integer.parseInt(config.getProperty("explicitWait"))));

		// ✅ Opening the base URL from config.properties
		driver.get().get(config.getProperty("url"));
	}

	/**
	 * ✅ Returns the WebDriver instance for use in test cases and Page Objects
	 */
	public static WebDriver getDriver() {
		return driver.get();
	}

	/**
	 * ✅ Takes screenshot on test failure - Saves screenshots in screenshots/ folder
	 */
	public static void takeScreenshot(String testName) {
		try {
			File srcFile = ((TakesScreenshot) driver.get()).getScreenshotAs(OutputType.FILE);
			File destFile = new File("screenshots/" + testName + ".png");
			FileUtils.copyFile(srcFile, destFile);
			System.out.println("📸 Screenshot saved: " + destFile.getAbsolutePath());
		} catch (Exception e) {
			System.out.println("⚠️ Screenshot capture failed: " + e.getMessage());
		}
	}

	/**
	 * ✅ Closes WebDriver after each test (TestNG @AfterMethod) - Ensures proper
	 * browser cleanup - Removes ThreadLocal WebDriver instance
	 */
//	@AfterMethod
//	public void quitDriver() {
//		if (driver.get() != null) {
//			driver.get().quit();
//			driver.remove();
//		}
//	}
}
