package com.kingsleynorth.automation.tests;

import com.google.protobuf.Duration;
import com.kingsleynorth.automation.base.BaseTest;
import com.kingsleynorth.automation.pages.LoginPage;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * 🚀 LoginTest - Test cases for Login functionality.
 * - Uses TestNG annotations for test execution
 * - Extends BaseTest to initialize WebDriver
 * - Calls LoginPage methods for performing actions
 */
public class LoginTest extends BaseTest {
    
    /**
     * ✅ Test Case: Valid login scenario.
     */
	/*
	 * @Test public void testValidLogin() { LoginPage loginPage = new
	 * LoginPage(getDriver()); loginPage.login("srikantho@kensium.com",
	 * "SOken$1um");
	 * 
	 * 
	 * 
	 * // ✅ Assert that the login was successful (Modify as per your application)
	 * Assert.assertTrue(getDriver().getTitle().contains("My Account"),
	 * "❌ Login failed! User is not on My Account page."); }
	 */
    
    @Test
    public void testValidLogin() {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.login("srikantho@kensium.com", "SOken$1um");

        // ✅ Wait for the title to contain "My Account"
        BaseTest.wait.until(ExpectedConditions.titleContains("My Account"));

        // ✅ Assert login success
        Assert.assertTrue(getDriver().getTitle().contains("My Account"),
                "❌ Login failed! Expected title containing 'My Account', but got: " + getDriver().getTitle());
    }

    /**
     * ✅ Test Case: Invalid login scenario.
     */
    @Test
    public void testInvalidLogin() {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.login("invalidUser", "wrongPassword");

        // ✅ Assert error message is displayed
        Assert.assertEquals(loginPage.getErrorMessage(), "Invalid credentials",
                "❌ Error message not displayed correctly!");
    }
}
